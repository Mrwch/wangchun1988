﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Aga.Controls.Tree;
using Aga.Controls.Tree.NodeControls;
using Aga.Controls;

namespace ZQMachManager
{

    public partial class DummyToolbox : ToolWindow
    {
        private TreeModel _model;
        private Font _childFont;
        MainForm mm;
        public DummyToolbox(MainForm m)
        {
            InitializeComponent();
            mm = m;
         //   _tree.NodeMouseClick += new EventHandler<TreeNodeAdvMouseEventArgs>(_tree_NodeMouseClick);

            _nodeTextBox.DrawText += new EventHandler<DrawEventArgs>(_nodeTextBox_DrawText);
            _model = new TreeModel();
            _childFont = new Font(_tree.Font.FontFamily, 18, FontStyle.Bold);
            _tree.Model = _model;

            _tree.BeginUpdate();
            for (int i = 0; i < 10; i++)
            {
                Node node = AddRoot();
                for (int n = 0; n < 500; n++)
                {
                    Node child = AddChild(node);
                    for (int k = 0; k < 5; k++)
                        AddChildMachine(child);
                }
            }
            _tree.EndUpdate();


            if (_tree.Root.Children.Count > 0)
            {
                if (!_tree.Root.Children[0].IsExpanded)
                    _tree.ExpandAll();
                //else
                //    _tree.ExpandAll();
            }
        }
        void _nodeTextBox_DrawText(object sender, DrawEventArgs e)
        {
            if ((e.Node.Tag as MyNode).Text.StartsWith("Child"))
            {
                e.TextColor = Color.Red;
                e.Font = _childFont;
            }
        }

        private Node AddRoot()
        {
            Node node = new MyNode("品牌" + _model.Nodes.Count.ToString());
            _model.Nodes.Add(node);
            return node;
        }

        private Node AddChild(Node parent)
        {
            Node node = new MyNode("型号 " + parent.Nodes.Count.ToString());
            parent.Nodes.Add(node);
            return node;
        }
        private Node AddChildMachine(Node parent)
        {
            Node node = new MyNode("设备 " + parent.Nodes.Count.ToString());
            parent.Nodes.Add(node);
            return node;
        }

        private void _tree_ItemDrag(object sender, ItemDragEventArgs e)
        {
            _tree.DoDragDropSelectedNodes(DragDropEffects.Move);
        }

        private void _tree_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(typeof(TreeNodeAdv[])) && _tree.DropPosition.Node != null)
            {
                TreeNodeAdv[] nodes = e.Data.GetData(typeof(TreeNodeAdv[])) as TreeNodeAdv[];
                TreeNodeAdv parent = _tree.DropPosition.Node;
                if (_tree.DropPosition.Position != NodePosition.Inside)
                    parent = parent.Parent;

                foreach (TreeNodeAdv node in nodes)
                    if (!CheckNodeParent(parent, node))
                    {
                        e.Effect = DragDropEffects.None;
                        return;
                    }

                e.Effect = e.AllowedEffect;
            }
        }

        private bool CheckNodeParent(TreeNodeAdv parent, TreeNodeAdv node)
        {
            while (parent != null)
            {
                if (node == parent)
                    return false;
                else
                    parent = parent.Parent;
            }
            return true;
        }

        private void _tree_DragDrop(object sender, DragEventArgs e)
        {
            _tree.BeginUpdate();

            TreeNodeAdv[] nodes = (TreeNodeAdv[])e.Data.GetData(typeof(TreeNodeAdv[]));
            Node dropNode = _tree.DropPosition.Node.Tag as Node;
            if (_tree.DropPosition.Position == NodePosition.Inside)
            {
                foreach (TreeNodeAdv n in nodes)
                {
                    (n.Tag as Node).Parent = dropNode;
                }
                _tree.DropPosition.Node.IsExpanded = true;
            }
            else
            {
                Node parent = dropNode.Parent;
                Node nextItem = dropNode;
                if (_tree.DropPosition.Position == NodePosition.After)
                    nextItem = dropNode.NextNode;

                foreach (TreeNodeAdv node in nodes)
                    (node.Tag as Node).Parent = null;

                int index = -1;
                index = parent.Nodes.IndexOf(nextItem);
                foreach (TreeNodeAdv node in nodes)
                {
                    Node item = node.Tag as Node;
                    if (index == -1)
                        parent.Nodes.Add(item);
                    else
                    {
                        parent.Nodes.Insert(index, item);
                        index++;
                    }
                }
            }

            _tree.EndUpdate();
        }
        private void _tree_NodeMouseDoubleClick(object sender, TreeNodeAdvMouseEventArgs e)
        {
            //if (e.Control is NodeTextBox)
            //    MessageBox.Show(e.Node.Tag.ToString());

            if (e.Node.Children.Count == 0)
                mm.newMachineForm(e.Node.Tag.ToString());


        }

        private void _timer_Tick(object sender, EventArgs e)
        {
           
            _tree.Refresh();

        }
    }
}
